
//	░█████╗░██╗░░░██╗███╗░░░███╗███████╗░██████╗███████╗███╗░░██╗░██████╗███████╗
//	██╔══██╗██║░░░██║████╗░████║██╔════╝██╔════╝██╔════╝████╗░██║██╔════╝██╔════╝
//	██║░░╚═╝██║░░░██║██╔████╔██║█████╗░░╚█████╗░█████╗░░██╔██╗██║╚█████╗░█████╗░░
//	██║░░██╗██║░░░██║██║╚██╔╝██║██╔══╝░░░╚═══██╗██╔══╝░░██║╚████║░╚═══██╗██╔══╝░░
//	╚█████╔╝╚██████╔╝██║░╚═╝░██║███████╗██████╔╝███████╗██║░╚███║██████╔╝███████╗
//	░╚════╝░░╚═════╝░╚═╝░░░░░╚═╝╚══════╝╚═════╝░╚══════╝╚═╝░░╚══╝╚═════╝░╚══════╝


// WIP
var frametimes = []
var fps_prev = 0
var value_prev = []
var last_update_time = 0
// WIP

const window_x = UI.AddSliderInt("window_x", 0, Global.GetScreenSize()[0])
const window_y = UI.AddSliderInt("window_y", 0, Global.GetScreenSize()[1])
const rate = Global.Tickrate()

function HSVtoRGB(h, s, v)
{
    var r, g, b, i, f, p, q, t;

    i = Math.floor(h * 6);
    f = h * 6 - i;
    p = v * (1 - s);
    q = v * (1 - f * s);
    t = v * (1 - (1 - f) * s);

    switch (i % 6)
    {
        case 0: r = v, g = t, b = p; break;
        case 1: r = q, g = v, b = p; break;
        case 2: r = p, g = v, b = t; break;
        case 3: r = p, g = q, b = v; break;
        case 4: r = t, g = p, b = v; break;
        case 5: r = v, g = p, b = q; break;
    }

    return { r: Math.round(r * 255), g: Math.round(g * 255), b: Math.round(b * 255) };
}

function update_menu()
{
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "window_x", false)
    UI.SetEnabled("Misc", "JAVASCRIPT", "Script items", "window_y", false)
}
update_menu();

/**
 * Checks if a point is inside a perimeter
 *
 * @param vec
 * @param x
 * @param y
 * @param x2
 * @param y2
 * @returns {boolean}
 */
function is_draging(vec, x, y, x2, y2)
{
    return (vec[0] > x) && (vec[1] > y) && (vec[0] < x2) && (vec[1] < y2)
}

function main()
{
   var color_static = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Bar color")
   var color_static3 = UI.GetColor("Misc", "JAVASCRIPT", "Script items", "Bar color 2")
   var color_static2 = UI.GetColor("Misc", "JAVASCRIPT", "Script items", '"tap" color')
   var colors = HSVtoRGB(Global.Realtime() * UI.GetValue("Misc", "JAVASCRIPT", "Script items", "Gradient Speed Watermark"), 1, 1);
   const x = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "window_x");
   const y = UI.GetValue("Misc", "JAVASCRIPT", "Script items", "window_y");         
   //const ping = Math.floor(Global.Latency() * 1000 / 1.5 );
   const ping = Math.floor(Global.Latency() * 1000 / 1.5 );
   const fps = Math.floor( 1 / Global.Frametime() );
   var today = new Date();
   
   

   if (today.getMinutes() > 9)
   {
        var time = today.getHours() + ":" + today.getMinutes()
   }
   else
   {
        var time = today.getHours() + ":" + "0" + today.getMinutes()
   }

   if (UI.GetValue("Enable onetap watermark") == true) 
   {
	   UI.SetValue("Misc", "PERFORMANCE & INFORMATION", "Information", "Watermark", false);

		   Render.FilledRect(x + 1, y + 10, 171, 35, [55, 55, 55, 255]);
           Render.Rect(x + 6, y + 15, 160, 25, [2, 2, 2, 100]);
		   Render.FilledRect(x + 7, y + 15, 160, 25, [25, 25, 25, 200]);
		   Render.GradientRect(x + 6, y + 15, 161, 3, 1, color_static, color_static3);
           Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
		   ////////
           Render.String(x + 34, y + 24, 0, "tap", color_static2, 8);
		   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
		   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
           Render.String(x + 50, y + 24, 0, "  |  " +
           "           | " + 
           time, [255, 255, 255, 255], 8);
		
		
	   if (Global.IsKeyPressed(1)) {
			 const mouse_xy = Global.GetCursorPosition();
			 if (is_draging(mouse_xy, x, y, x + 200, y + 30)) {
			  if (UI.IsMenuOpen( ) == false)
				return;
				 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_x", mouse_xy[0] - 100);
				 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_y", mouse_xy[1] - 20);
			 }
		 }
    
		
		if (UI.GetValue("Enable ping") == true) 
			{
			   Render.FilledRect(x + 1, y + 10, 217, 35, [55, 55, 55, 255]);
			   Render.Rect(x + 6, y + 15, 205, 25, [2, 2, 2, 100]);
			   Render.FilledRect(x + 7, y + 15, 205, 25, [25, 25, 25, 200]);
			   Render.GradientRect(x + 6, y + 15, 206, 3, 1, color_static, color_static3);
			   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
			   ////////
			   Render.String(x + 34, y + 24, 0, "tap", color_static2, 8);
			   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 50, y + 24, 0, "  |  " +
			   "           | " + 
			   ping + 
			   " ms " +
			   "| " + 
			   time, [255, 255, 255, 255], 8);
			
			if (UI.GetValue("Enable tickrate") == true) 
				{
						   Render.FilledRect(x + 1, y + 10, 273, 35, [55, 55, 55, 255]);
						   Render.Rect(x + 6, y + 15, 264, 25, [2, 2, 2, 100]);
						   Render.FilledRect(x + 6, y + 15, 263, 25, [25, 25, 25, 200]);
						   Render.GradientRect(x + 6, y + 15, 264, 3, 1, color_static, color_static3);
						   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
						   ////////
						   Render.String(x + 34, y + 24, 0, "tap", color_static2, 8);
						   Render.String(x + 55, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 113, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 128, y + 24, 0, rate + "", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 145, y + 24, 0, "tick", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 160, y + 24, 0, "" +
						   "   | " + 
						   ping + 
						   " ms " +
						   " | " + 
						   time, [255, 255, 255, 255], 8);
				}
			}
						
   }
				////////////////////////////////v1 rainbow////////////////////////////////////////
	if (UI.GetValue("Enable onetap watermark") == true && UI.GetValue("Enable Rainbow bar/text") == true)
   {
	   UI.SetValue("Misc", "PERFORMANCE & INFORMATION", "Information", "Watermark", false);

		   Render.FilledRect(x + 1, y + 10, 171, 35, [55, 55, 55, 255]);
           Render.Rect(x + 6, y + 15, 160, 25, [2, 2, 2, 100]);
		   Render.FilledRect(x + 7, y + 15, 160, 25, [25, 25, 25, 200]);
		   Render.GradientRect(x + 6, y + 15, 161, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
           Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
		   ////////
           Render.String(x + 34, y + 24, 0, "tap", [ colors.g, colors.b, colors.r, 255], 8);
		   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
		   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
           Render.String(x + 50, y + 24, 0, "  |  " +
           "           | " + 
           time, [255, 255, 255, 255], 8);
		
		
	   if (Global.IsKeyPressed(1)) {
			 const mouse_xy = Global.GetCursorPosition();
			 if (is_draging(mouse_xy, x, y, x + 200, y + 30)) {
			  if (UI.IsMenuOpen( ) == false)
				return;
				 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_x", mouse_xy[0] - 100);
				 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_y", mouse_xy[1] - 20);
			 }
		 }
    
		
		if (UI.GetValue("Enable ping") == true) 
			{
			   Render.FilledRect(x + 1, y + 10, 217, 35, [55, 55, 55, 255]);
			   Render.Rect(x + 6, y + 15, 205, 25, [2, 2, 2, 100]);
			   Render.FilledRect(x + 7, y + 15, 205, 25, [25, 25, 25, 200]);
			   Render.GradientRect(x + 6, y + 15, 206, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
			   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
			   ////////
			   Render.String(x + 34, y + 24, 0, "tap", [ colors.g, colors.b, colors.r, 255], 8);
			   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 50, y + 24, 0, "  |  " +
			   "           | " + 
			   ping + 
			   " ms " +
			   "| " + 
			   time, [255, 255, 255, 255], 8);
			
			}
			if (UI.GetValue("Enable tickrate") == true) 
				{
						   Render.FilledRect(x + 1, y + 10, 273, 35, [55, 55, 55, 255]);
						   Render.Rect(x + 6, y + 15, 264, 25, [2, 2, 2, 100]);
						   Render.FilledRect(x + 6, y + 15, 263, 25, [25, 25, 25, 200]);
						   Render.GradientRect(x + 6, y + 15, 264, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
						   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
						   ////////
						   Render.String(x + 34, y + 24, 0, "tap", [ colors.g, colors.b, colors.r, 255], 8);
						   Render.String(x + 55, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 113, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 128, y + 24, 0, rate + "", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 145, y + 24, 0, "tick", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 160, y + 24, 0, "" +
						   "   | " + 
						   ping + 
						   " ms " +
						   " | " + 
						   time, [255, 255, 255, 255], 8);
				}
   }
   
				//////////////v2/////////////////////////////////////////////////////////////////////////////////////
				

	
	if (UI.GetValue("Enable onetap watermark V2") == true) 
   {
		  UI.SetValue("Misc", "PERFORMANCE & INFORMATION", "Information", "Watermark", false);
		   Render.FilledRect(x + 7, y + 15, 160, 25, [25, 25, 25, 255]);
		   Render.GradientRect(x + 6, y + 15, 161, 3, 1, color_static, color_static3);
           Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
		   ////////
           Render.String(x + 34, y + 24, 0, "tap", color_static2, 8);
		   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
		   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
           Render.String(x + 50, y + 24, 0, "  |  " +
           "           | " + 
           time, [255, 255, 255, 255], 8);
		
		
	   if (Global.IsKeyPressed(1)) {
			 const mouse_xy = Global.GetCursorPosition();
			 if (is_draging(mouse_xy, x, y, x + 200, y + 30)) {
			  if (UI.IsMenuOpen( ) == false)
				return;
				 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_x", mouse_xy[0] - 100);
				 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_y", mouse_xy[1] - 20);
			 }
		 }


		if (UI.GetValue("Enable ping") == true) 
			{
			   Render.Rect(x + 6, y + 15, 211, 25, [2, 2, 2, 100]);
			   Render.FilledRect(x + 6, y + 15, 210, 25, [25, 25, 25, 255]);
			   Render.GradientRect(x + 6, y + 15, 211, 3, 1, color_static, color_static3);
			   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
			   ////////
			   Render.String(x + 34, y + 24, 0, "tap", color_static2, 8);
			   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 50, y + 24, 0, "  |  " +
			   "           |  " + 
			   ping + 
			   " ms " +
			   " | " + 
			   time, [255, 255, 255, 255], 8);
		
			if (UI.GetValue("Enable tickrate") == true) 
					{
						Render.Rect(x + 6, y + 15, 266, 25, [2, 2, 2, 100]);
						Render.FilledRect(x + 6, y + 15, 265, 25, [25, 25, 25, 255]);
						Render.GradientRect(x + 6, y + 15, 266, 3, 1, color_static, color_static3);
						Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
						////////
						Render.String(x + 34, y + 24, 0, "tap", color_static2, 8);
						Render.String(x + 55, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 111, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 125, y + 24, 0, rate + "", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 142, y + 24, 0, "tick", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 128, y + 24, 0, "" +
						"          | " + 
						ping + 
						" ms " +
						" |  " + 
						time, [255, 255, 255, 255], 8);
					}	

			}
			
   }
      ///////////////////////////////v2 rainbow/////////////////////////////////////////////////////////////////////////
	if (UI.GetValue("Enable onetap watermark V2") == true && UI.GetValue("Enable Rainbow bar/text") == true) 
   {
		  UI.SetValue("Misc", "PERFORMANCE & INFORMATION", "Information", "Watermark", false);
		   Render.FilledRect(x + 7, y + 15, 160, 25, [25, 25, 25, 255]);
		   Render.GradientRect(x + 6, y + 15, 161, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
           Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
		   ////////
           Render.String(x + 34, y + 24, 0, "tap", [ colors.g, colors.b, colors.r, 255], 8);
		   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
		   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
           Render.String(x + 50, y + 24, 0, "  |  " +
           "           | " + 
           time, [255, 255, 255, 255], 8);
		
		
	   if (Global.IsKeyPressed(1)) {
			 const mouse_xy = Global.GetCursorPosition();
			 if (is_draging(mouse_xy, x, y, x + 200, y + 30)) {
			  if (UI.IsMenuOpen( ) == false)
				return;
				 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_x", mouse_xy[0] - 100);
				 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_y", mouse_xy[1] - 20);
			 }
		 }


		if (UI.GetValue("Enable ping") == true) 
			{
			   Render.Rect(x + 6, y + 15, 211, 25, [2, 2, 2, 100]);
			   Render.FilledRect(x + 6, y + 15, 210, 25, [25, 25, 25, 255]);
			   Render.GradientRect(x + 6, y + 15, 211, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
			   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
			   ////////
			   Render.String(x + 34, y + 24, 0, "tap", [ colors.g, colors.b, colors.r, 255], 8);
			   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 50, y + 24, 0, "  |  " +
			   "           |  " + 
			   ping + 
			   " ms " +
			   " | " + 
			   time, [255, 255, 255, 255], 8);
		
			if (UI.GetValue("Enable tickrate") == true) 
					{
						Render.Rect(x + 6, y + 15, 266, 25, [2, 2, 2, 100]);
						Render.FilledRect(x + 6, y + 15, 265, 25, [25, 25, 25, 255]);
						Render.GradientRect(x + 6, y + 15, 266, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
						Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
						////////
						Render.String(x + 34, y + 24, 0, "tap", [ colors.g, colors.b, colors.r, 255], 8);
						Render.String(x + 55, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 111, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 125, y + 24, 0, rate + "", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 142, y + 24, 0, "tick", [ 255, 255, 255, 255 ], 8);
						Render.String(x + 128, y + 24, 0, "" +
						"          | " + 
						ping + 
						" ms " +
						" |  " + 
						time, [255, 255, 255, 255], 8);
					}	
			}
		}
				////////////v3///////////////////////////////////////////////////////////////////////////////////////
				
	if (UI.GetValue("Enable onetap watermark V3") == true)
	{
			UI.SetValue("Misc", "PERFORMANCE & INFORMATION", "Information", "Watermark", false);
			   Render.GradientRect(x + 6, y + 16, 161, 25, 1, color_static, color_static3);
			   Render.FilledRect(x + 7, y + 15, 160, 25, [25, 25, 25, 255]);
			   Render.GradientRect(x + 6, y + 15, 161, 3, 1, color_static, color_static3);
			   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
			   ////////
			   Render.String(x + 34, y + 24, 0, "tap", color_static2, 8);
			   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 50, y + 24, 0, "  |  " +
			   "           | " + 
			   time, [255, 255, 255, 255], 8);
			
			
		   
		
			if (UI.GetValue("Enable ping") == true)
				{
				   Render.GradientRect(x + 6, y + 16, 211, 25, 1, color_static, color_static3);
				   Render.FilledRect(x + 7, y + 15, 210, 25, [25, 25, 25, 255]);
				   Render.GradientRect(x + 6, y + 15, 211, 3, 1, color_static, color_static3);
				   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
				   ////////
				   Render.String(x + 34, y + 24, 0, "tap", color_static2, 8);
				   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
				   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
				   Render.String(x + 50, y + 24, 0, "  |  " +
				   "           |  " + 
				   ping + 
				   " ms " +
				   " | " + 
				   time, [255, 255, 255, 255], 8);
				
				if (UI.GetValue("Enable tickrate") == true) 
						{
						   Render.GradientRect(x + 6, y + 16, 266, 25, 1, color_static, color_static3);
						   Render.FilledRect(x + 7, y + 15, 265, 25, [25, 25, 25, 255]);
						   Render.GradientRect(x + 6, y + 15, 266, 3, 1, color_static, color_static3);
						   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
						   ////////
						   Render.String(x + 34, y + 24, 0, "tap", color_static2, 8);
						   Render.String(x + 55, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 111, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 125, y + 24, 0, rate + "", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 142, y + 24, 0, "tick", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 128, y + 24, 0, "" +
						   "          | " + 
						   ping + 
						   " ms " +
						   " |  " + 
						   time, [255, 255, 255, 255], 8);
						}	
				}
		if (Global.IsKeyPressed(1)) {
			const mouse_xy = Global.GetCursorPosition();
				if (is_draging(mouse_xy, x, y, x + 200, y + 30)) {
				  if (UI.IsMenuOpen( ) == false)
					return;
					 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_x", mouse_xy[0] - 100);
					 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_y", mouse_xy[1] - 20);
				}
		}
	}	
	
	////////////v3 rainbow///////////////////////////////////////////////////////////////////////////////////////
	if (UI.GetValue("Enable onetap watermark V3") == true && UI.GetValue("Enable Rainbow bar/text") == true)
	{
			UI.SetValue("Misc", "PERFORMANCE & INFORMATION", "Information", "Watermark", false);
			   Render.Rect(x + 6, y + 16, 161, 25, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
			   Render.FilledRect(x + 7, y + 15, 160, 25, [25, 25, 25, 255]);
			   Render.GradientRect(x + 6, y + 15, 161, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
			   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
			   ////////
			   Render.String(x + 34, y + 24, 0, "tap", [ colors.g, colors.b, colors.r, 255], 8);
			   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
			   Render.String(x + 50, y + 24, 0, "  |  " +
			   "           | " + 
			   time, [255, 255, 255, 255], 8);
			
			
		   
		
			if (UI.GetValue("Enable ping") == true)
				{
				   Render.Rect(x + 6, y + 16, 211, 25, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
				   Render.FilledRect(x + 7, y + 15, 210, 25, [25, 25, 25, 255]);
				   Render.GradientRect(x + 6, y + 15, 211, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
				   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
				   ////////
				   Render.String(x + 34, y + 24, 0, "tap", [ colors.g, colors.b, colors.r, 255], 8);
				   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
				   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
				   Render.String(x + 50, y + 24, 0, "  |  " +
				   "           |  " + 
				   ping + 
				   " ms " +
				   " | " + 
				   time, [255, 255, 255, 255], 8);
				
				if (UI.GetValue("Enable tickrate") == true) 
						{
						   Render.Rect(x + 6, y + 16, 266, 25, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
						   Render.FilledRect(x + 7, y + 15, 265, 25, [25, 25, 25, 255]);
						   Render.GradientRect(x + 6, y + 15, 266, 3, 1, [colors.g, colors.b, colors.r, 255], [colors.r, colors.g, colors.b, 255]);
						   Render.String(x + 12, y + 24, 0, "one", [255, 255, 255, 255], 8);
						   ////////
						   Render.String(x + 34, y + 24, 0, "tap", [ colors.g, colors.b, colors.r, 255], 8);
						   Render.String(x + 55, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 68, y + 24, 0, fps + "", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 92, y + 24, 0, "fps", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 111, y + 24, 0, " | ", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 125, y + 24, 0, rate + "", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 142, y + 24, 0, "tick", [ 255, 255, 255, 255 ], 8);
						   Render.String(x + 128, y + 24, 0, "" +
						   "          | " + 
						   ping + 
						   " ms " +
						   " |  " + 
						   time, [255, 255, 255, 255], 8);
						}	
				}
		if (Global.IsKeyPressed(1)) {
			const mouse_xy = Global.GetCursorPosition();
				if (is_draging(mouse_xy, x, y, x + 200, y + 30)) {
				  if (UI.IsMenuOpen( ) == false)
					return;
					 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_x", mouse_xy[0] - 100);
					 UI.SetValue("Misc", "JAVASCRIPT", "Script items", "window_y", mouse_xy[1] - 20);
				}
		}
	}
}



// Callback our main function & stuff
UI.AddSliderInt("", 0, 0);
UI.AddCheckbox("Enable onetap watermark")
UI.AddCheckbox("Enable onetap watermark V2")
UI.AddCheckbox("Enable onetap watermark V3")
UI.AddColorPicker("Bar color")
UI.AddColorPicker("Bar color 2")
UI.AddColorPicker('"tap" color')
UI.AddCheckbox("Enable Rainbow bar/text")
UI.AddCheckbox("Enable ping")
UI.AddCheckbox("Enable tickrate")
//Global.RegisterCallback("Draw", "watermark")
Global.PrintColor([186, 235, 52, 255], "\n\nOnetap Watermark Loaded!\n\n\n")
Global.RegisterCallback("Draw", "main")
UI.AddSliderFloat("Gradient Speed Watermark", 0.01, 1.0);
UI.AddSliderInt("", 0, 0);
UI.SetValue("Misc", "JAVASCRIPT", "Script items", "Gradient Speed Watermark", 0.1);