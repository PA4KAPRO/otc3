function onCreateMove()
{
at.RegisterCallback("CreateMove", "onCreateMove");

    var movement = UserCMD.GetMovement();

    forward = movement[0];
    side = movement[1];
    up = movement[2];

    Cheat.Print("Forward: " + forward + "\nSide: " + side + "\nUp: " +  up + "\n");
}
