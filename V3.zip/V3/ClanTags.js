﻿					// ty elleqt for the code <3
// added all clantags and edited by Calypso
// clantag #3 "md5" create by shpex <3

UI.AddDropdown( "[Calypso] ClanTag", ["Disable", "gamesense", "LЁGЁNDЁN.", "LЁGЁNDЁN ANIMATED", "fatality.win old", "AIMWARE.net", "sippin'fanta", "pphud", "AGVEITE" ] );
UI.AddSliderInt( "[Calypso] ClanTag Speed", 3, 5 );
var lasttime = 0;
function onRender( )
{
    var tag = UI.GetValue( "Script Items", "[Calypso] ClanTag" );
    var speed = UI.GetValue( "Script Items", "[Calypso] ClanTag Speed" );
    var time = parseInt((Globals.Curtime() * speed))
    if (time != lasttime)
    {
        if(tag == 0) { Local.SetClanTag(""); }
        if(tag == 1)
            {
            switch((time) % 30)
            {
                case 0: { Local.SetClanTag("             ga"); break; }
                case 1: { Local.SetClanTag("            gam"); break; }
                case 2: { Local.SetClanTag("           game"); break; }
                case 3: { Local.SetClanTag("          games"); break; }
                case 4: { Local.SetClanTag("         gamese"); break; }
                case 5: { Local.SetClanTag("        gamesen"); break; }
                case 6: { Local.SetClanTag("       gamesens"); break; }
                case 7: { Local.SetClanTag("      gamesense       "); break; }
                case 8: { Local.SetClanTag("     gamesense       "); break; }
                case 9: { Local.SetClanTag("    gamesense       "); break; }
                case 10:{ Local.SetClanTag("   gamesense       "); break; }
                case 11:{ Local.SetClanTag("  gamesense       "); break; }
				case 12:{ Local.SetClanTag(" gamesense        "); break; }
                case 13:{ Local.SetClanTag("gamesense       "); break; }
                case 14:{ Local.SetClanTag(" gamesense       "); break; }
				case 15:{ Local.SetClanTag("  gamesense        "); break; }
                case 16:{ Local.SetClanTag("   gamesense    "); break; }
				case 17:{ Local.SetClanTag("   gamesense       "); break; }
                case 18:{ Local.SetClanTag("    gamesense       "); break; }
                case 19:{ Local.SetClanTag("     gamesense       "); break; }
                case 20:{ Local.SetClanTag("     gamesense       "); break; }
                case 21:{ Local.SetClanTag("amesense       "); break; }
                case 22:{ Local.SetClanTag("mesense        "); break; }
                case 23:{ Local.SetClanTag("esense         "); break; }
                case 24:{ Local.SetClanTag("sense          "); break; }
                case 25:{ Local.SetClanTag("ense           "); break; }
                case 26:{ Local.SetClanTag("nse            "); break; }
			    case 27:{ Local.SetClanTag("se             "); break; }
			    case 28:{ Local.SetClanTag("e              "); break; }
			    case 29:{ Local.SetClanTag("               "); break; }
                            case 30:{ Local.SetClanTag("               "); break; }
            }
        }
        if(tag == 2)
            {
            switch((time) % 23)
            {
                case 0: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 1: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 2: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 3: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 4: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 5: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 6: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 7: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 8: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 9: { Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 10:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 11:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 12:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 13:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 14:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 15:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 16:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 17:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 18:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 19:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 20:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 21:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
                case 22:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
            }
        }
	    if(tag == 3)
            {
            switch((time) % 41)
            {
				case 0: { Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 1:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 2:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 3:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 4:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 5:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 6:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 7:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 8: { Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 9:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 10:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 11:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 12:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 13:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 14:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 15:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 16: { Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 17:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 18:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 19:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 20:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 21:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 22:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 23:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 24: { Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 25:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 26:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 27:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 28:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 29:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 30:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 31:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 32: { Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 33:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 34:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 35:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 36:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 37:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 38:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 39:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 40:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 41:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 42:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
				case 43:{ Local.SetClanTag("LЁGЁNDЁN."); break; }
				case 44:{ Local.SetClanTag("LЁGЁNDЁN.\n"); break; }
                
            }
        }
	    if(tag == 4)
            {
            switch((time) % 31)
            {
                case 0: { Local.SetClanTag("              f"); break; }
                case 1: { Local.SetClanTag("             fa"); break; }
                case 2: { Local.SetClanTag("            fat"); break; }
                case 3: { Local.SetClanTag("           fata"); break; }
                case 4: { Local.SetClanTag("          fatal"); break; }
                case 5: { Local.SetClanTag("         fatali"); break; }
                case 6: { Local.SetClanTag("        fatalit"); break; }
                case 7: { Local.SetClanTag("       fatality"); break; }
                case 8: { Local.SetClanTag("      fatality."); break; }
                case 9: { Local.SetClanTag("     fatality.w"); break; }
                case 10:{ Local.SetClanTag("    fatality.wi"); break; }
                case 11:{ Local.SetClanTag("   fatality.win"); break; }
				case 12:{ Local.SetClanTag("  fatality.win "); break; }
				case 13:{ Local.SetClanTag(" fatality.win  "); break; }
				case 19:{ Local.SetClanTag("fatality.win   "); break; }
				case 20:{ Local.SetClanTag("atality.win    "); break; }
				case 21:{ Local.SetClanTag("tality.win     "); break; }
				case 22:{ Local.SetClanTag("ality.win      "); break; }
				case 23:{ Local.SetClanTag("lity.win       "); break; }
                case 24:{ Local.SetClanTag("ity.win        "); break; }
                case 25:{ Local.SetClanTag("ty.win         "); break; }
                case 26:{ Local.SetClanTag("y.win          "); break; }
                case 27:{ Local.SetClanTag(".win           "); break; }
                case 28:{ Local.SetClanTag("win            "); break; }
                case 29:{ Local.SetClanTag("in             "); break; }
                case 30:{ Local.SetClanTag("n              "); break; }
            }
        }
		if(tag == 5)
            {
            switch((time) % 16)
            {
                case 0: { Local.SetClanTag("AIMWARE.net"); break; }
				case 1: { Local.SetClanTag("AIMWARE.net "); break; }
				case 2: { Local.SetClanTag("AIMWARE.net "); break; }
				case 3: { Local.SetClanTag("AIMWARE.net "); break; }
				case 4: { Local.SetClanTag("AIMWARE.net "); break; }
                case 5: { Local.SetClanTag("IMWARE.net A"); break; }
                case 6: { Local.SetClanTag("MWARE.net AI"); break; }
				case 7: { Local.SetClanTag("WARE.net AIM"); break; }
				case 8: { Local.SetClanTag("ARE.net AIMW"); break; }
				case 9:{ Local.SetClanTag("RE.net AIMWA"); break; }
				case 10:{ Local.SetClanTag("E.net AIMWAR"); break; }
				case 11:{ Local.SetClanTag(".net AIMWARE"); break; }
				case 12:{ Local.SetClanTag("net AIMWARE."); break; }
				case 13:{ Local.SetClanTag("et AIMWARE.n"); break; }
				case 14:{ Local.SetClanTag("t AIMWARE.ne"); break; }
				case 15:{ Local.SetClanTag(" AIMWARE.net"); break; }
				
				
            }
        }
		if(tag == 6)
            {
            switch((time) % 29)
            {
                case 0: { Local.SetClanTag("sp"); break; }
                case 1: { Local.SetClanTag("spi"); break; }
                case 2: { Local.SetClanTag("spin"); break; }
                case 3: { Local.SetClanTag("spin"); break; }
                case 4: { Local.SetClanTag("spinni"); break; }
                case 5: { Local.SetClanTag("spinnin"); break; }
                case 6: { Local.SetClanTag("spinnin'"); break; }
                case 7: { Local.SetClanTag("spinnin'f"); break; }
                case 8: { Local.SetClanTag("spinnin'fa"); break; }
                case 9: { Local.SetClanTag("spinnin'fan"); break; }
                case 10:{ Local.SetClanTag("spinnin'fant"); break; }
                case 11:{ Local.SetClanTag("spinnin'fanta"); break; }
				case 12:{ Local.SetClanTag("spinnin'fanta"); break; }
				case 13:{ Local.SetClanTag("innin'fanta"); break; }
				case 14:{ Local.SetClanTag("nnin'fanta"); break; }
				case 15:{ Local.SetClanTag("nin'fanta"); break; }
				case 16:{ Local.SetClanTag("in'fanta"); break; }
				case 17:{ Local.SetClanTag("n'fanta"); break; }
				case 18:{ Local.SetClanTag("'fanta"); break; }
                case 19:{ Local.SetClanTag("fanta"); break; }
                case 25:{ Local.SetClanTag("fant"); break; }
                case 26:{ Local.SetClanTag("fan"); break; }
                case 27:{ Local.SetClanTag("fa"); break; }
                case 28:{ Local.SetClanTag("f"); break; }
            }
        }
		if(tag == 7)
            {
            switch((time) % 17)
            {
				case 0: { Local.SetClanTag("legit\n"); break; }
				case 1:{ Local.SetClanTag("legit"); break; }
				case 2:{ Local.SetClanTag("legit\n"); break; }
				case 3:{ Local.SetClanTag("legit"); break; }
				case 4:{ Local.SetClanTag("legit\n"); break; }
				case 5:{ Local.SetClanTag("legit"); break; }
				case 6:{ Local.SetClanTag("legit\n"); break; }
				case 7:{ Local.SetClanTag("legit"); break; }
				case 8: { Local.SetClanTag("legit\n"); break; }
				case 9:{ Local.SetClanTag("legit"); break; }
				case 10:{ Local.SetClanTag("legit\n"); break; }
				case 11:{ Local.SetClanTag("legit"); break; }
				case 12:{ Local.SetClanTag("legit\n"); break; }
				case 13:{ Local.SetClanTag("legit"); break; }
				case 14:{ Local.SetClanTag("legit\n"); break; }
				case 15:{ Local.SetClanTag("legit"); break; }
				case 16: { Local.SetClanTag("legit\n"); break; }
            }
        }
		if(tag == 8)
            {
            switch((time) % 19)
            {
                case 0: { Local.SetClanTag("E"); break; }
                case 1: { Local.SetClanTag("E B"); break; }
				case 2: { Local.SetClanTag("E B L"); break; }
				case 3: { Local.SetClanTag("E B L A"); break; }
				case 4: { Local.SetClanTag("E B L A N"); break; }
				case 5: { Local.SetClanTag("E B L A N ."); break; }
				case 6: { Local.SetClanTag("E B L A N . C"); break; }
				case 7: { Local.SetClanTag("E B L A N . C C");break; } 
				case 8: { Local.SetClanTag("E B L A N . C");break; }
				case 9: { Local.SetClanTag("E B L A N ."); break; }
				case 10:{ Local.SetClanTag("E B L A N"); break; }
				case 11:{ Local.SetClanTag("E B L A"); break; }
				case 12:{ Local.SetClanTag("E B L"); break; }
				case 13:{ Local.SetClanTag("E B"); break; }
				case 14:{ Local.SetClanTag("E"); break; }
            }
        }
    }
    lasttime = time;
}
Cheat.RegisterCallback("Draw", "onRender");